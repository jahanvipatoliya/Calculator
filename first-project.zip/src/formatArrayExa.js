import React from "react";
import TableArray from "./tableArray";

class FormatArrayExample extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [
        {
          UserId: 22,
          UserName: "Mehmet",
          UserSurname: "Baran",
          DOBYear: 1987,
          DOBCity: 63,
        },
        {
          UserId: 23,
          UserName: "SFA",
          UserSurname: "Baran",
          DOBYear: 2001,
          DOBCity: 34,
        },
        {
          UserId: 24,
          UserName: "jay",
          UserSurname: "Baran",
          DOBYear: 2002,
          DOBCity: 63,
        },
      ],
    };
  }

  render() {
    let ListNew = [];
    this.state.data.map((item, i) => {
      const UserList = {
        id: item.UserId,
        name: item.UserName,
        surname: item.UserSurname,
        birthYear: item.DOBYear,
        birthCity: item.DOBCity,
      };
      ListNew[i] = UserList;
      return item;
    });

    var columns = [
      { field: "id", headerName: "ID", width: 70 },
      { field: "name", headerName: "Name", width: 160 },
      { field: "surname", headerName: "Surname", width: 160 },
      { field: "birthYear", headerName: "Birth Year", width: 160 },
      { field: "birthCity", headerName: "Birth City", width: 160 },
    ];
    return (
      <React.Fragment>
        <h1>Format Array 2</h1>
        <TableArray data={ListNew} columns={columns} />
      </React.Fragment>
    );
  }
}

export default FormatArrayExample;
