import React from "react";
import { Container } from "@material-ui/core";

import fruit from "./checkboxArray.json";

class CheckBox extends React.Component {
  render() {
    return (
      <input
        type="checkbox"
        id={this.props.id}
        value={this.props.value}
        onChange={this.props.onChange}
      />
    );
  }
}

class CheckedBoxArray extends React.Component {
  constructor(props) {
    super(props);
    this.state = { optionsChecked: [] };
  }

  changeHandler = (event) => {
    let checkedArray = this.state.optionsChecked;
    let selectedValue = event.target.value;

    if (event.target.checked === true) {
      checkedArray.push(selectedValue);
      this.setState({
        optionsChecked: checkedArray,
      });
    } else {
      let valueIndex = checkedArray.indexOf(selectedValue);
      checkedArray.splice(valueIndex, 1);

      this.setState({
        optionsChecked: checkedArray,
      });
    }
  };

  render() {
    console.log(this.state.optionsChecked);
    let outputCheckBox = fruit.map((val, index) => {
      return (
        <div>
          <CheckBox
            value={val.name}
            key={val.id}
            onChange={this.changeHandler}
          />
          <label htmlFor={index}>{val.name}</label>
        </div>
      );
    });
    return (
      <React.Fragment>
        <Container>{outputCheckBox}</Container>
      </React.Fragment>
    );
  }
}
export default CheckedBoxArray;
