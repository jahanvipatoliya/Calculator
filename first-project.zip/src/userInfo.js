import React from "react";
import UserData from "./userData";
import { makeStyles } from "@material-ui/core/styles";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import ListItemAvatar from "@material-ui/core/ListItemAvatar";
import Avatar from "@material-ui/core/Avatar";
import ImageIcon from "@material-ui/icons/Image";
import WorkIcon from "@material-ui/icons/Work";
import BeachAccessIcon from "@material-ui/icons/BeachAccess";
import "./css/userInfo.css";

class UserInfo extends React.Component {
  constructor() {
    super();
    this.state = {
      userPersonalData: "",
    };
  }

  handleClick = (val) => {
    this.setState({ userPersonalData: val });
  };

  useStyles = makeStyles((theme) => ({
    root: {
      width: "100%",
      maxWidth: 360,
      backgroundColor: theme.palette.background.paper,
    },
  }));

  render() {
    const classes = this.useStyles;
    return (
      <div>
        <ul>
          {UserData.map((val, index) => (
            <li
              onClick={() => {
                this.handleClick(val);
              }}
            >
              {val.UserID} <span>{val.UserFullName}</span>
            </li>
          ))}
        </ul>
        <ul>
          <li>{this.state.userPersonalData.UserID}</li>
          <li>{this.state.userPersonalData.UserFullName}</li>
          <li>{this.state.userPersonalData.UserPhone}</li>
          <li>{this.state.userPersonalData.UserEmail}</li>
          <li>
            <img
              src={this.state.userPersonalData.UserProfilePicture}
              alt={this.state.userPersonalData.UserProfilePicture}
            />
          </li>
          <li>{this.state.userPersonalData.UserCurrencyCode}</li>
          <li>{this.state.userPersonalData.UserGender}</li>
          <li>{this.state.userPersonalData.UserBirthDate}</li>
        </ul>
      </div>
    );
  }
}

export default UserInfo;
