const UserData = [
    {
      "UserID": 1,
      "UserFullName": "testing",
      "UserPhone": "+91123123123",
      "UserEmail": "testing@gmail.com",
      "UserProfilePicture": "https://s3-ap-southeast-2.amazonaws.com/youchampdev/placeholders/user.png",
      "UserCurrencyCode": "IND",
      "UserGender": null,
      "UserBirthDate": null
    },
    {
      "UserID": 2,
      "UserFullName": "krupali_1",
      "UserPhone": "+919876543210",
      "UserEmail": "krupali@gmail.com",
      "UserProfilePicture": "https://s3-ap-southeast-2.amazonaws.com/youchampdev/placeholders/user.png",
      "UserCurrencyCode": "INR",
      "UserGender": null,
      "UserBirthDate": null
    },
    {
      "UserID": 3,
      "UserFullName": "jahanvi",
      "UserPhone": "+9195376589531",
      "UserEmail": "jahanvi.jnext@gmail.com",
      "UserProfilePicture": "https://s3-ap-southeast-2.amazonaws.com/youchampdev/placeholders/user.png",
      "UserCurrencyCode": "AUD",
      "UserGender": "FEMALE",
      "UserBirthDate": "2020-07-17"
    },
    {
      "UserID": 4,
      "UserFullName": "Brijender",
      "UserPhone": "+61466846906",
      "UserEmail": "brijender@digiground.com.au",
      "UserProfilePicture": "https://testing.youchampapp.com/upload/aws/files/redirect/wwltNI.1603346986431.camera.jpg",
      "UserCurrencyCode": "AUD",
      "UserGender": "Male",
      "UserBirthDate": "1980-07-20"
    },
    {
      "UserID": 5,
      "UserFullName": "krushali",
      "UserPhone": "+9170161948261",
      "UserEmail": "krushali@gmail.com",
      "UserProfilePicture": "https://s3-ap-southeast-2.amazonaws.com/youchampdev/placeholders/user.png",
      "UserCurrencyCode": "INR",
      "UserGender": null,
      "UserBirthDate": null
    },
    {
      "UserID": 6,
      "UserFullName": "krupali",
      "UserPhone": "+9190992588671",
      "UserEmail": "krupali@gmail.com",
      "UserProfilePicture": "https://s3-ap-southeast-2.amazonaws.com/youchampdev/placeholders/user.png",
      "UserCurrencyCode": "INR",
      "UserGender": null,
      "UserBirthDate": "1970-01-01"
    },
    {
      "UserID": 7,
      "UserFullName": "12311111111111111111111111111111111111111111",
      "UserPhone": "+614260640000",
      "UserEmail": "zhouyitong0226123456@gmail.com",
      "UserProfilePicture": "https://s3-ap-southeast-2.amazonaws.com/youchampdev/placeholders/user.png",
      "UserCurrencyCode": "AFN",
      "UserGender": "FEMALE",
      "UserBirthDate": "2022-03-09"
    },
  ]


export default UserData;