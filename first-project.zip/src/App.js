import React from "react";
import TableMap from "./table";
import ArrayTest from "./2ndReact";
import FormData from "./form";
import UserInfo from "./userInfo";
import SwitchCaseComp from "./switchCaseComp";
import AddData from "./addData";
import Pagination from "./pagination";
import ToggleDiv from "./ToggleDiv";
import TabExample from "./tabs";
import ModalExample from "./modal";
import MaterialExample from "./material-ui";
import Accordian from "./accordian";
import TemporaryDrawer from "./drawer";
import SteppersExample from "./steppers";
import ImageSliderExample from "./image-slider";
import Counter from "./counter";
import ReactLifeCycle from "./react-life-cycle";
import TableArray from "./tableArray";
import FormatArrayExample from "./formatArrayExa";
import ArrayFormat from "./arrayFormat";
import PropTypesExample from "./propTypes";
import SortingExample from "./SortingDataExample";
import SortingArrayFormat from "./sortingArrayFormat";
import StateSelectSort from "./stateSortingArray";
import MonthArrayDataSort from "./monthDataArray";
import CalculatorExample from "./calculator/calculator";
import CheckedBoxArray from "./checkboxArray";
import SalaryApp from "./salaryAppD";
import VotingApp from "./votingApp";
import MomentDateExa from "./momentjsDate";
import SearchBar from "./searchbar";
import DropDownSearch from "./dropdownSearch";
import ImageUpload from "./imageUpload";
import ActiveLink from "./activeLink";

// Functional Components
import CounterFunCompo from "./functional-component/counter";
import TableFunctCompo from "./functional-component/table";
import AddDataFunCompo from "./functional-component/addData";
import FormDataFunCompo from "./functional-component/form-Functional";
import ToDoListFunCompo from "./ToDoList-functional/ToDoListFunCompo";

class MapTest extends React.Component {
  render() {
    return (
      <div>
        <ActiveLink />
        <ImageUpload />
        <SearchBar />
        <DropDownSearch />
        <MomentDateExa />
        <VotingApp />
        <CheckedBoxArray />
        <SalaryApp />
        <CalculatorExample />
        <MonthArrayDataSort />
        <StateSelectSort />
        <SortingArrayFormat />
        <SortingExample />
        <FormatArrayExample />
        <TableArray />
        <PropTypesExample />
        <ArrayFormat />
        <ToDoListFunCompo />
        <FormDataFunCompo />
        <AddDataFunCompo />
        <TableFunctCompo />
        <CounterFunCompo />
        <ReactLifeCycle />
        <Counter />
        <ImageSliderExample />
        <SteppersExample />
        <TemporaryDrawer />
        <ModalExample />
        <TabExample />
        <Accordian />
        <MaterialExample />
        <ToggleDiv />
        <Pagination />
        <AddData />
        <SwitchCaseComp />
        <FormData />
        <TableMap />
        <ArrayTest />
        <UserInfo />
      </div>
    );
  }
}

export default MapTest;
