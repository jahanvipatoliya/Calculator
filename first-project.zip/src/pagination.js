import React from "react";
import { UserDataBase } from "./dataForPagination";
import Helmet from "react-helmet";

class Pagination extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      datatoshow: 5,
    };
  }
  render() {
    return (
      <div>
        <Helmet>
          <title>Pagination</title>
        </Helmet>
        <h2 style={{ textAlign: "center" }}>Pagination</h2>
        <table>
          <tr>
            <th>No.</th>
            <th>Name</th>
            <th>surname</th>
            <th>Birth Year</th>
            <th>Birth City</th>
          </tr>
          {UserDataBase.slice(0, this.state.datatoshow).map((val, index) => (
            <tr key={index}>
              <td>{val.id}</td>
              <td>{val.name}</td>
              <td>{val.surname}</td>
              <td>{val.birthYear}</td>
              <td>{val.birthCity}</td>
            </tr>
          ))}
          {UserDataBase.length <= this.state.datatoshow ? (
            "No more Data to show"
          ) : (
            <button
              onClick={() => {
                this.setState({ datatoshow: this.state.datatoshow + 5 });
              }}
            >
              Read More
            </button>
          )}
        </table>
      </div>
    );
  }
}

export default Pagination;
