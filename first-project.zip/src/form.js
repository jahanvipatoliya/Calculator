import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import TextField from "@material-ui/core/TextField";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import Alert from "@material-ui/lab/Alert";
import Button from "@material-ui/core/Button";
import "./css/form.css";
import { Helmet } from "react-helmet";

class FormData extends React.Component {
  constructor() {
    super();
    this.state = {
      input: {},
      errors: {},
    };
  }

  changeHandler = (e) => {
    let input = this.state.input;
    input[e.target.name] = e.target.value;

    this.setState({
      input,
    });
  };

  SubmitHandler = (e) => {
    e.preventDefault();

    if (this.Validate()) {
      let input = {};
      input["phone"] = " ";
      input["name"] = " ";
      input["email"] = " ";
      input["password"] = " ";
      input["repeat_password"] = " ";
      this.setState({
        input: input,
      });
    }
  };

  Validate = () => {
    let input = this.state.input;
    let errors = {};
    let isValid = true;

    if (!input["country"]) {
      isValid = false;
      errors["country"] = "please select the country.";
    }

    if (!input["phone"]) {
      isValid = false;
      errors["phone"] = "please enter your phone.";
    }

    if (!input["name"]) {
      isValid = false;
      errors["name"] = "please enter your name.";
    }

    if (typeof input["email"] !== "") {
      var pattern = new RegExp(
        /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
      );
      if (!pattern.test(input["email"])) {
        isValid = false;
        errors["email"] = "Please enter valid email address.";
      }
    }

    if (!input["password"]) {
      isValid = false;
      errors["password"] = "please enter password.";
    }

    if (!input["repeat_password"]) {
      isValid = false;
      errors["repeat_password"] = "please enter confirm password.";
    }

    if (input["password"] && input["repeat_password"]) {
      if (input["password"] !== input["repeat_password"]) {
        isValid = false;
        errors["password"] = "Passwords don't match.";
      }
    }

    this.setState({
      errors: errors,
    });

    return isValid;
  };

  useStyles = makeStyles((theme) => ({
    root: {
      "& > *": {
        margin: theme.spacing(1),
        width: "25ch",
      },
    },
    formControl: {
      margin: theme.spacing(1),
      minWidth: 120,
    },
    selectEmpty: {
      marginTop: theme.spacing(2),
    },
  }));

  render() {
    const classes = this.useStyles;
    return (
      <div className="container_form">
        <Helmet>
          <title>Form</title>
        </Helmet>
        <form
          onSubmit={this.SubmitHandler}
          className={classes.root}
          autoComplete="off"
        >
          <br />
          <FormControl variant="outlined" className={classes.formControl}>
            <InputLabel id="demo-simple-select-outlined-label">
              Country
            </InputLabel>
            <Select
              labelId="demo-simple-select-outlined-label"
              id="demo-simple-select-outlined"
              onChange={this.changeHandler}
              name="country"
              label="Country"
            >
              <MenuItem name="australia" value="australia">
                Australia
              </MenuItem>
              <MenuItem name="india" value="india">
                India
              </MenuItem>
              <MenuItem name="newzealand" value="newzealand">
                NewZealand
              </MenuItem>
              <MenuItem name="singapore" value="singapore">
                Singapore
              </MenuItem>
            </Select>
            <div>
              {this.state.errors.country ? (
                <Alert severity="error">{this.state.errors.country}</Alert>
              ) : null}
            </div>
            <br />
            <TextField
              id="outlined-basic"
              label="Your Phone Number"
              variant="outlined"
              name="phone"
              value={this.state.input.phone}
              onChange={this.changeHandler}
            />
            <div>
              {this.state.errors.phone ? (
                <Alert severity="error">{this.state.errors.phone}</Alert>
              ) : null}
            </div>
            <br />
            <TextField
              id="outlined-basic"
              label="Name"
              name="name"
              variant="outlined"
              value={this.state.input.name}
              onChange={this.changeHandler}
            />
            <div>
              {this.state.errors.name ? (
                <Alert severity="error">{this.state.errors.name}</Alert>
              ) : null}
            </div>
            <br />
            <TextField
              id="outlined-basic"
              label="Email"
              name="email"
              variant="outlined"
              value={this.state.input.email}
              onChange={this.changeHandler}
            />
            <div>
              {this.state.errors.email ? (
                <Alert severity="error">{this.state.errors.email}</Alert>
              ) : null}
            </div>
            <br />
            <TextField
              id="outlined-basic"
              label="Password"
              name="password"
              type="password"
              variant="outlined"
              value={this.state.input.password}
              onChange={this.changeHandler}
            />
            <div>
              {this.state.errors.password ? (
                <Alert severity="error">{this.state.errors.password}</Alert>
              ) : null}
            </div>
            <br />
            <TextField
              id="outlined-basic"
              label="Confirm Password"
              name="repeat_password"
              type="password"
              variant="outlined"
              value={this.state.input.repeat_password}
              onChange={this.changeHandler}
            />
            <div>
              {this.state.errors.repeat_password ? (
                <Alert severity="error">
                  {this.state.errors.repeat_password}
                </Alert>
              ) : null}
            </div>
            <br />
            <Button type="submit" variant="contained" color="primary">
              Submit
            </Button>
          </FormControl>
        </form>
      </div>
    );
  }
}

const Form = () => {
  return (
    <>
      <FormData />
    </>
  );
};

export default Form;
