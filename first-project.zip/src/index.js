import React from "react";
import ReactDOM from "react-dom";
import MapTest from "./App";
import "./css/index.css";
import MenuBar from "./Router";

ReactDOM.render(<MenuBar />, document.getElementById("root"));
