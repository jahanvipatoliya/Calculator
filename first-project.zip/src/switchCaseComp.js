import React from "react";
const items = [
  { name: "Apple", category: "fruit" },
  { name: "Potato", category: "vegitable" },
  { name: "cashew", category: "dry fruit" },
  { name: "Mango", category: "fruit" },
  { name: "Tomato", category: "vegitable" },
  { name: "Banana", category: "fruit" },
];

class SwitchCaseComp extends React.Component {
  getItemInfo = (val) => {
    switch (val.category) {
      case "vegitable":
        return (
          <>
            <p>{val.name}</p>
          </>
        );
    }
  };

  render() {
    return (
      <div>
        <h3 style={{ textAlign: "center" }}>Switch Case Statement</h3>
        {items.map((val, index) => (
          <>{this.getItemInfo(val)}</>
        ))}
      </div>
    );
  }
}

export default SwitchCaseComp;
