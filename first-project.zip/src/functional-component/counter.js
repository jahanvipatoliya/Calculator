import React, { useState, useRef, useEffect } from "react";
import ReactDOM from "react-dom";
import { Button, Typography } from "@material-ui/core";
import Container from "@material-ui/core/Container";

function useCustomCount() {
  const [count, setCount] = useState({ count: 0 });

  const OperationPerf = (val) => {
    setCount({ count: val === "add" ? count.count + 1 : count.count - 1 });
  };

  return { count, OperationPerf };
}

const CounterFunCompo = () => {
  const customCount = useCustomCount();
  return (
    <React.Fragment>
      <Container maxWidth="sm" align="center">
        <h2>Counter Functional Component</h2>
        <br />
        <Typography>{customCount.count.count}</Typography>
        <Button
          variant="contained"
          color="primary"
          style={{ margin: 5 }}
          onClick={() => customCount.OperationPerf("add")}
        >
          Add
        </Button>
        <Button
          variant="contained"
          color="secondary"
          style={{ margin: 5 }}
          onClick={() => customCount.OperationPerf("sub")}
        >
          Remove
        </Button>
      </Container>
    </React.Fragment>
  );
};

export default CounterFunCompo;
