import React, { useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Container } from "@material-ui/core";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import TextField from "@material-ui/core/TextField";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import clsx from "clsx";
import InputAdornment from "@material-ui/core/InputAdornment";
import OutlinedInput from "@material-ui/core/OutlinedInput";
import IconButton from "@material-ui/core/IconButton";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";
import Alert from "@material-ui/lab/Alert";
import Button from "@material-ui/core/Button";
import "../css/form.css";

const useStyles = makeStyles((theme) => ({
  root: {
    "& > *": {
      margin: theme.spacing(1),
      width: "25ch",
    },
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));

const FormDataFunCompo = () => {
  const [showPwd, setShowpwd] = useState({
    showPassword: false,
    showConfPassword: false,
  });

  const [values, setValues] = useState({});

  const [errors, setErrors] = useState({});

  const handleClickShowPassword = () => {
    setShowpwd({ ...showPwd, showPassword: !showPwd.showPassword });
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  const handleClickShowConfPassword = () => {
    setShowpwd({ ...showPwd, showConfPassword: !showPwd.showConfPassword });
  };

  const handleMouseDownConfPassword = (event) => {
    event.preventDefault();
  };

  const changeHandler = (e) => {
    const { name, value } = e.target;
    setValues({ ...values, [name]: value });
  };

  const submitHandler = (e) => {
    e.preventDefault();
    setErrors(isValidate(values));
    setValues({});
  };

  const isValidate = (val) => {
    let errors = {};
    if (!val.country) {
      errors.country = "country is required";
    }
    if (!val.phone) {
      errors.phone = "phone is required";
    }

    if (typeof val.email !== "") {
      var pattern = new RegExp(
        /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
      );
      if (!pattern.test(val.email)) {
        errors.email = "Please enter valid email address.";
      }
    }

    if (!val.name) {
      errors.name = "name is required";
    }
    if (!val.password) {
      errors.password = "password is required";
    }
    if (!val.repeat_password) {
      errors.repeat_password = "confirm password is required";
    }

    if (val.password && val.repeat_password) {
      if (val.password !== val.repeat_password) {
        errors.password = "Passwords don't match.";
      }
    }

    return errors;
  };

  //   const Validate = (input) => {
  //     let errors = {};
  //     let isValid = true;

  //     if (!input["country"]) {
  //       isValid = false;
  //       errors["country"] = "please select the country.";
  //     }

  //     if (!input["phone"]) {
  //       isValid = false;
  //       errors["phone"] = "please enter your phone.";
  //     }

  //     if (!input["name"]) {
  //       isValid = false;
  //       errors["name"] = "please enter your name.";
  //     }

  //     if (typeof input["email"] !== "") {
  //       var pattern = new RegExp(
  //         /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
  //       );
  //       if (!pattern.test(input["email"])) {
  //         isValid = false;
  //         errors["email"] = "Please enter valid email address.";
  //       }
  //     }

  //     if (!input["password"]) {
  //       isValid = false;
  //       errors["password"] = "please enter password.";
  //     }

  //     if (!input["repeat_password"]) {
  //       isValid = false;
  //       errors["repeat_password"] = "please enter confirm password.";
  //     }

  //     if (input["password"] && input["repeat_password"]) {
  //       if (input["password"] !== input["repeat_password"]) {
  //         isValid = false;
  //         errors["password"] = "Passwords don't match.";
  //       }
  //     }

  //     setErrors({ errors });

  //     return isValid;
  //   };

  const classes = useStyles();
  return (
    <React.Fragment>
      <h1 align="center">Form Functional Component</h1>
      <Container width="sm" align="center" className="container_form">
        <form className={classes.root} onSubmit={(e) => submitHandler(e)}>
          <FormControl variant="outlined" className={classes.formControl}>
            <InputLabel id="demo-simple-select-outlined-label">
              Country
            </InputLabel>
            <Select
              labelId="demo-simple-select-outlined-label"
              id="demo-simple-select-outlined"
              name="country"
              value={values.country}
              onChange={(e) => changeHandler(e)}
              label="Country"
            >
              <MenuItem name="australia" value="australia">
                Australia
              </MenuItem>
              <MenuItem name="india" value="india">
                India
              </MenuItem>
              <MenuItem name="newzealand" value="newzealand">
                NewZealand
              </MenuItem>
              <MenuItem name="singapore" value="singapore">
                Singapore
              </MenuItem>
            </Select>
            <div>
              {errors.country ? (
                <Alert severity="error">{errors.country}</Alert>
              ) : null}
            </div>
            <br />
            <TextField
              id="outlined-basic"
              label="Phone"
              variant="outlined"
              name="phone"
              value={values.phone}
              onChange={(e) => changeHandler(e)}
            />
            <div>
              {errors.phone ? (
                <Alert severity="error">{errors.phone}</Alert>
              ) : null}
            </div>
            <br />
            <TextField
              id="outlined-basic"
              label="Name"
              variant="outlined"
              name="name"
              value={values.name}
              onChange={(e) => changeHandler(e)}
            />
            <div>
              {errors.name ? (
                <Alert severity="error">{errors.name}</Alert>
              ) : null}
            </div>
            <br />
            <TextField
              id="outlined-basic"
              label="Email"
              variant="outlined"
              name="email"
              value={values.email}
              onChange={(e) => changeHandler(e)}
            />
            <div>
              {errors.email ? (
                <Alert severity="error">{errors.email}</Alert>
              ) : null}
            </div>
            <br />
            <FormControl
              className={clsx(classes.margin, classes.textField)}
              variant="outlined"
            >
              <InputLabel htmlFor="outlined-adornment-password">
                Password
              </InputLabel>
              <OutlinedInput
                id="outlined-adornment-password"
                type={showPwd.showPassword ? "text" : "password"}
                name="password"
                onChange={(e) => changeHandler(e)}
                value={values.password}
                endAdornment={
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={handleClickShowPassword}
                      onMouseDown={handleMouseDownPassword}
                      edge="end"
                    >
                      {showPwd.showPassword ? (
                        <Visibility />
                      ) : (
                        <VisibilityOff />
                      )}
                    </IconButton>
                  </InputAdornment>
                }
                labelWidth={70}
              />
            </FormControl>
            <div>
              {errors.password ? (
                <Alert severity="error">{errors.password}</Alert>
              ) : null}
            </div>
            <br />
            <FormControl
              className={clsx(classes.margin, classes.textField)}
              variant="outlined"
            >
              <InputLabel htmlFor="outlined-adornment-password">
                Confirm Password
              </InputLabel>
              <OutlinedInput
                id="outlined-adornment-password"
                type={showPwd.showConfPassword ? "text" : "password"}
                name="repeat_password"
                value={values.repeat_password}
                onChange={(e) => changeHandler(e)}
                endAdornment={
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={handleClickShowConfPassword}
                      onMouseDown={handleMouseDownConfPassword}
                      edge="end"
                    >
                      {showPwd.showConfPassword ? (
                        <Visibility />
                      ) : (
                        <VisibilityOff />
                      )}
                    </IconButton>
                  </InputAdornment>
                }
                labelWidth={70}
              />
            </FormControl>
            <div>
              {errors.repeat_password ? (
                <Alert severity="error">{errors.repeat_password}</Alert>
              ) : null}
            </div>
            <br />
            <Button type="submit" variant="contained" color="primary">
              Submit
            </Button>
          </FormControl>
        </form>
        <div>{JSON.stringify(values)}</div>
      </Container>
    </React.Fragment>
  );
};

export default FormDataFunCompo;
