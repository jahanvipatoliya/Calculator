import { Container } from "@material-ui/core";
import React, { useState } from "react";

const AddDataFunCompo = () => {
  const [list, setList] = useState([]);
  const [input, setInput] = useState({ id: "", name: "" });

  const changeHandler = (e) => {
    const { name, value } = e.target;
    setInput({
      ...input,
      [name]: value,
    });
  };

  const submitHandler = (e) => {
    e.preventDefault();
    list.push(input);
    setInput({ id: "", name: "" });
    console.log(list);
  };
  return (
    <React.Fragment>
      <h1 align="center">Add Data Functional Component</h1>
      <Container align="center">
        <form onSubmit={(e) => submitHandler(e)}>
          <label>
            Id:
            <input
              type="text"
              name="id"
              value={input.id}
              placeholder="please enter ID"
              onChange={(e) => changeHandler(e)}
            />
          </label>
          <br />
          <label>
            Name :
            <input
              type="text"
              name="name"
              value={input.name}
              placeholder="please enter name"
              onChange={(e) => changeHandler(e)}
            />
          </label>
          <br />
          <input type="submit" value="submit" />
        </form>
        <ul>
          {list.map((val, index) => (
            <li key={index}>
              {val.id} <span style={{ color: "red" }}>{val.name}</span>
            </li>
          ))}
        </ul>
      </Container>
    </React.Fragment>
  );
};

export default AddDataFunCompo;
