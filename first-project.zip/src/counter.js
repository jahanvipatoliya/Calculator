import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import Container from "@material-ui/core/Container";
import Helmet from "react-helmet";

class Counter extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 0,
    };
    this.OperationPerf = this.OperationPerf.bind(this);
  }

  useStyles = makeStyles((theme) => ({
    root: {
      "& > *": {
        margin: theme.spacing(1),
      },
    },
  }));

  OperationPerf = (type) => {
    this.setState((prevState) => {
      return {
        count: type == "add" ? prevState.count + 1 : prevState.count - 1,
      };
    });
  };

  render() {
    const classes = this.useStyles;

    return (
      <div>
        <Helmet>
          <title>Counter</title>
        </Helmet>
        <div className={classes.root}>
          <Container maxWidth="sm" align="center">
            <Typography style={{ margin: 5 }}>{this.state.count}</Typography>

            <Button
              style={{ margin: 5 }}
              variant="contained"
              color="primary"
              onClick={() => this.OperationPerf("add")}
            >
              Add
            </Button>
            <Button
              style={{ margin: 5 }}
              variant="contained"
              color="secondary"
              onClick={() => this.OperationPerf("sub")}
            >
              remove
            </Button>
          </Container>
        </div>
      </div>
    );
  }
}

export default Counter;
