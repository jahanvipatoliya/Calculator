import React from "react";
import mediaArr from "./media.json";

class MonthArrayDataSort extends React.Component {
  render() {
    return (
      <React.Fragment>
        <h3 align="center">Month Array Media ,Link and Docs</h3>
        {mediaArr.map((val, index) => {
          return (
            <div key={index}>
              <h1 key={index}>{val.month_name}</h1>
              {val.data.map((dataval, i) => {
                return (
                  <div key={i}>
                    {dataval.videourl ? (
                      <video width="320" height="240" controls>
                        <source src={dataval.videourl} type="video/mp4" />
                      </video>
                    ) : (
                      <img
                        style={{ width: "200px" }}
                        src={dataval.image}
                        alt={dataval._id}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          );
        })}
      </React.Fragment>
    );
  }
}

export default MonthArrayDataSort;
