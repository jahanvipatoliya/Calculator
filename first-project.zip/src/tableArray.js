import React from "react";
import Container from "@material-ui/core/Container";
import { DataGrid } from "@material-ui/data-grid";
import "./css/table.css";

class TableArray extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: this.props.data,
    };
  }

  render() {
    const columns = this.props.columns;
    const rows = this.state.data;

    console.log(this.props.data);
    return (
      <div className="table">
        <Container>
          <div style={{ height: 370, width: "100%" }}>
            {rows !== undefined && columns !== undefined && (
              <DataGrid
                rows={rows}
                columns={columns}
                pageSize={5}
                checkboxSelection
              />
            )}
          </div>
        </Container>
      </div>
    );
  }
}

export default TableArray;
