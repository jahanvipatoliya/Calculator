import React from "react";
import "./css/form.css";

class AddData extends React.Component {
  constructor() {
    super();
    this.state = {
      list: [],
      input: {
        id: "",
        name: "",
      },
    };
  }

  ChangeHandler = (e) => {
    const input = this.state.input;
    input[e.target.name] = e.target.value;

    this.setState({
      input,
    });
  };

  submitHandler = (e) => {
    const input = this.state.input;
    var tempList = this.state.list;
    tempList.push(input);
    this.setState({ list: tempList, input: {} });
    console.log(tempList);
    e.preventDefault();
  };

  render() {
    return (
      <div>
        <form onSubmit={this.submitHandler}>
          <label>
            Id:
            <input
              type="text"
              name="id"
              value={this.state.input.id}
              placeholder="please enter ID"
              onChange={this.ChangeHandler}
            />
          </label>
          <br />
          <label>
            Name :
            <input
              type="text"
              name="name"
              value={this.state.input.name}
              placeholder="please enter name"
              onChange={this.ChangeHandler}
            />
          </label>
          <br />
          <input type="submit" value="submit" />
        </form>
        <ol>
          {this.state.list.map((val, index) => (
            <li>
              {val.id} <span style={{ color: "red" }}>{val.name}</span>
            </li>
          ))}
        </ol>
      </div>
    );
  }
}

export default AddData;
