import React from "react";
import TableArray from "./tableArray";

class ArrayFormat extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [
        {
          id: 1,
          name: "Mehmet",
          surname: "Baran",
          birthYear: 1987,
          birthCity: 63,
        },
        {
          id: 2,
          name: "SFA",
          surname: "Baran",
          birthYear: 2001,
          birthCity: 34,
        },
        {
          id: 3,
          name: "jay",
          surname: "Baran",
          birthYear: 2002,
          birthCity: 63,
        },
        {
          id: 4,
          name: "Zerya",
          surname: "Baran",
          birthYear: 2003,
          birthCity: 34,
        },
        {
          id: 5,
          name: "raj",
          surname: "Baran",
          birthYear: 2004,
          birthCity: 63,
        },
        {
          id: 6,
          name: "darshan",
          surname: "Baran",
          birthYear: 2005,
          birthCity: 34,
        },
        {
          id: 7,
          name: "lname",
          surname: "Baran",
          birthYear: 2006,
          birthCity: 63,
        },
        {
          id: 8,
          name: "Betül",
          surname: "Baran",
          birthYear: 2017,
          birthCity: 34,
        },
        {
          id: 9,
          name: "Mehmet john",
          surname: "Baran",
          birthYear: 2019,
          birthCity: 63,
        },
        {
          id: 10,
          name: "tül",
          surname: "Baran",
          birthYear: 2020,
          birthCity: 34,
        },
      ],
      columns: [
        { field: "id", headerName: "ID", width: 70 },
        { field: "name", headerName: "Name", width: 160 },
        { field: "surname", headerName: "Surname", width: 160 },
        { field: "birthYear", headerName: "Birth Year", width: 160 },
        { field: "birthCity", headerName: "Birth City", width: 160 },
      ],
    };
  }

  render() {
    return (
      <React.Fragment>
        <h1 align="center">Array Format</h1>
        <TableArray data={this.state.data} columns={this.state.columns} />
      </React.Fragment>
    );
  }
}

export default ArrayFormat;
