import React from "react";
import { Helmet } from "react-helmet";
import { ArrData } from "./ArrData";
import "./css/nList.css";

const nList = (val) => {
  return (
    <>
      <div>
        <h2 className>{val.title}</h2>
        <ol className="subCategory">
          {val.list.map((list, index) => (
            <li key={list.SubCategoryID}>
              {list.SubCategoryID} <span>{list.SubCategoryName}</span>
            </li>
          ))}
        </ol>
      </div>
    </>
  );
};

class ArrayTest extends React.Component {
  render() {
    return (
      <div>
        <Helmet>
          <title>Array List</title>
        </Helmet>
        {ArrData.map(nList)}
      </div>
    );
  }
}

export default ArrayTest;
