import React from "react";
import Container from "@material-ui/core/Container";
import { makeStyles } from "@material-ui/core/styles";
import { DataGrid } from "@material-ui/data-grid";
import { Helmet } from "react-helmet";
import "./css/table.css";

class TableMap extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [
        {
          id: 1,
          name: "Mehmet",
          surname: "Baran",
          birthYear: 1987,
          birthCity: 63,
        },
        {
          id: 2,
          name: "SFA",
          surname: "Baran",
          birthYear: 2001,
          birthCity: 34,
        },
        {
          id: 3,
          name: "jay",
          surname: "Baran",
          birthYear: 2002,
          birthCity: 63,
        },
        {
          id: 4,
          name: "Zerya",
          surname: "Baran",
          birthYear: 2003,
          birthCity: 34,
        },
        {
          id: 5,
          name: "raj",
          surname: "Baran",
          birthYear: 2004,
          birthCity: 63,
        },
        {
          id: 6,
          name: "darshan",
          surname: "Baran",
          birthYear: 2005,
          birthCity: 34,
        },
        {
          id: 7,
          name: "lname",
          surname: "Baran",
          birthYear: 2006,
          birthCity: 63,
        },
        {
          id: 8,
          name: "Betül",
          surname: "Baran",
          birthYear: 2017,
          birthCity: 34,
        },
        {
          id: 9,
          name: "Mehmet john",
          surname: "Baran",
          birthYear: 2019,
          birthCity: 63,
        },
        {
          id: 10,
          name: "tül",
          surname: "Baran",
          birthYear: 2020,
          birthCity: 34,
        },
      ],
      filtereCountry: [],
      val: "all",
    };
  }

  // Material-UI css
  useStyles = makeStyles((theme) => ({
    table: {
      minWidth: 650,
    },
    formControl: {
      margin: theme.spacing(1),
      minWidth: 120,
    },
    selectEmpty: {
      marginTop: theme.spacing(2),
    },
    root: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      "& > *": {
        margin: theme.spacing(1),
      },
    },
  }));

  render() {
    // let filteredName = this.state.data.filter(
    //   (item) => item.birthCity === parseInt(this.state.val)
    // );
    //let dataToPass = this.state.val === "all" ? this.state.data : filteredName;

    const classes = this.useStyles;

    const columns = [
      { field: "id", headerName: "ID", width: 70 },
      { field: "name", headerName: "Name", width: 160 },
      { field: "surname", headerName: "Surname", width: 160 },
      { field: "birthYear", headerName: "Birth Year", width: 160 },
      { field: "birthCity", headerName: "Birth City", width: 160 },
    ];
    const rows = this.state.data;
    // const columns = this.props.columns;

    console.log(this.props.data);
    return (
      <div className="table">
        <Container>
          <Helmet>
            <title>Table</title>
          </Helmet>
          <div style={{ height: 370, width: "100%" }}>
            <DataGrid
              rows={this.props.data}
              columns={this.props.columns}
              pageSize={5}
              checkboxSelection
            />
          </div>
        </Container>
      </div>
    );
  }
}

const TableExample = (props) => {
  return (
    <>
      <TableMap data={props.data} columns={props.columns} />
    </>
  );
};

export default TableExample;
