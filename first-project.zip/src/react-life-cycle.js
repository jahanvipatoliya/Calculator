import { Button, TextField } from "@material-ui/core";
import { Label } from "@material-ui/icons";
import React from "react";

class Content extends React.Component {
  //unsafe
  // componentWillMount = () => {
  //   console.log("Component will Mount is Called");
  // };

  // componentDidMount = () => {
  //   console.log("component Did Mount is called");
  // };

  // componentWillReceiveProps = (props) => {
  //   console.log("Component will recieve props");
  // };

  // shouldComponentUpdate = (newProps, newState) => {
  //   return true;
  // };

  // //unsafe
  // componentWillUpdate = (newProps, newState) => {
  //   console.log("component will update is called");
  // };

  // componentDidUpdate = (newProps, newState) => {
  //   console.log("component did Update is Callled");
  // };

  // componentWillUnmount = () => {
  //   console.log("component will unmount is called");
  // };

  render() {
    return (
      <React.Fragment>
        <h3>{this.props.myNumber}</h3>
      </React.Fragment>
    );
  }
}

class ReactLifeCycle extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: "HTML",
    };
  }

  getData = () => {
    setInterval(() => {
      console.log("Our Data is Fetched");
      this.setState({
        data: "React",
      });
    }, 2000);
  };

  componentDidMount = () => {
    this.getData();
  };

  render() {
    return (
      <React.Fragment>
        <h2 align="center">React life cycle</h2>
        <Content myNumber={this.state.data} />
      </React.Fragment>
    );
  }
}

export default ReactLifeCycle;
