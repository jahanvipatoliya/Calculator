import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import { Container } from "@material-ui/core";
import "./css/countryselect.css";
import countryList from "./countrylist.json";

class StateSelectSort extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: countryList,
      input: [],
    };
  }

  useStyles = makeStyles((theme) => ({
    formControl: {
      margin: theme.spacing(1),
      minWidth: 120,
    },
    selectEmpty: {
      marginTop: theme.spacing(2),
    },
  }));

  changeHandler = (e) => {
    let input = this.state.input;
    let value = e.target.value;
    input[e.target.name] = e.target.value;

    let updateList = countryList.filter(
      (updatedstate, i) => updatedstate.id === value
    );
    console.log(updateList);

    this.setState({
      input: updateList,
    });
  };

  render() {
    const classes = this.useStyles;
    return (
      <React.Fragment>
        <h2 align="center">Select State dropdown array sort</h2>
        <br />
        <Container align="center">
          <div className="country_block">
            <FormControl variant="outlined" className={classes.formControl}>
              <InputLabel id="demo-simple-select-outlined-label">
                State
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                name="state"
                value={this.state.input.state}
                onChange={this.changeHandler}
                label="State"
              >
                {this.state.data.map((val, index) => {
                  return (
                    <MenuItem key={index} value={val.id}>
                      {val.name}
                    </MenuItem>
                  );
                })}
              </Select>
            </FormControl>
            &nbsp;&nbsp;&nbsp;
            <FormControl variant="outlined" className={classes.formControl}>
              <InputLabel id="demo-simple-select-outlined-label">
                City
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                name="city"
                // onChange={this.changeHandler}
                value={this.state.input.city}
                label="City"
              >
                <MenuItem>Select City</MenuItem>
                {this.state.input.map((val, i) => {
                  return (
                    <div key={i}>
                      {val.locals.map((city, p) => {
                        return (
                          <MenuItem key={p} value={city.name}>
                            {city.name}
                          </MenuItem>
                        );
                      })}
                    </div>
                  );
                })}
              </Select>
            </FormControl>
          </div>
        </Container>
      </React.Fragment>
    );
  }
}

export default StateSelectSort;
