import { Container } from "@material-ui/core";
import React from "react";

class VotingApp extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      voter: [],
      name: "",
      age: "",
      allowed: 0,
      notallowed: 0,
    };
  }

  submitHandler = (e) => {
    e.preventDefault();
    const { name, age, voter, allowed, notallowed } = this.state;
    const voteruser = {
      name,
      age,
    };

    voter.push(voteruser);
    this.setState({ voter });

    if (age > 18) {
      this.setState({ allowed: allowed + 1 });
    } else {
      this.setState({ notallowed: notallowed + 1 });
    }
    this.setState({ name: "", age: "" });
  };

  changeHandler = (e) => {
    let { name, value } = e.target;
    this.setState({
      [name]: value,
    });
  };

  render() {
    console.log(this.state.voter);
    return (
      <div>
        <React.Fragment>
          <Container>
            <h1 align="center">Voting App</h1>
            <h3>Allowed Voter :&nbsp;{this.state.allowed}</h3>
            <h3>Not Allowed Voter :&nbsp;{this.state.notallowed}</h3>
            <br />
            <div>
              <form onSubmit={this.submitHandler}>
                <label>
                  Name : &nbsp;
                  <input
                    type="text"
                    name="name"
                    value={this.state.name}
                    onChange={this.changeHandler}
                  />
                </label>
                <br />
                <label>
                  age : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <input
                    type="text"
                    name="age"
                    value={this.state.age}
                    onChange={this.changeHandler}
                  />
                </label>
                <br />
                <br />
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="submit" value="submit" />
              </form>
            </div>
            <br />
            <div>
              <h4>Voters</h4>
              {this.state.voter.map((val, index) => {
                return (
                  <p>
                    <b>Name:</b>
                    {val.name}&nbsp;
                    <span>
                      <b>Age:&nbsp;{val.age}</b>
                    </span>
                  </p>
                );
              })}
            </div>
          </Container>
        </React.Fragment>
      </div>
    );
  }
}

export default VotingApp;
