import React from "react";

class SalaryApp extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      salaryInfo: [],
      salaryTypeName: "",
      fixedSalary: "",
      incentive: "",
      minOrders: "",
      employeeInfo: [],
      employeeName: "",
      employeeOrdersDone: "",
      employeeSalaryType: "No Salary Type",
    };
  }

  textChange = (e) => {
    this.setState({
      [e.target.name]: e.target.value,
    });
  };

  submitForm = (e) => {
    e.preventDefault();
    const {
      salaryTypeName,
      fixedSalary,
      incentive,
      minOrders,
      salaryInfo,
    } = this.state;
    const salaryInfoObj = {
      salaryTypeName,
      fixedSalary,
      incentive,
      minOrders,
    };

    salaryInfo.push(salaryInfoObj);
    this.setState({
      salaryInfo,
    });
    e.target.reset();
  };

  renderTable1 = () => {
    const salaryInfo = this.state.salaryInfo;
    const data = salaryInfo.map((d, i) => {
      return (
        <tr key={i}>
          <td>{i + 1}</td>
          <td>{d.salaryTypeName}</td>
          <td>{d.fixedSalary}</td>
          <td>{d.incentive}</td>
          <td>{d.minOrders}</td>
        </tr>
      );
    });
    return data;
  };

  renderSalaryType = () => {
    const salaryInfo = this.state.salaryInfo;
    const data = salaryInfo.map((d, i) => {
      return (
        <option value={d.salaryTypeName} key={i}>
          {d.salaryTypeName}
        </option>
      );
    });
    return data;
  };

  submitEmployeeForm = (e) => {
    e.preventDefault();
    let {
      employeeName,
      employeeOrdersDone,
      employeeSalaryType,
      employeeInfo,
      salaryInfo,
    } = this.state;

    if (employeeSalaryType === "No Salary Type") {
      return console.log("select a valid salary type");
    }
    let fixedSalary;
    let incentive;
    let minOrders;
    var data;
    for (data of salaryInfo) {
      if (data.salaryTypeName === employeeSalaryType) {
        fixedSalary = data.fixedSalary;
        incentive = data.incentive;
        minOrders = data.minOrders;
        break;
      }
    }
    fixedSalary = parseInt(fixedSalary);
    employeeOrdersDone = parseInt(employeeOrdersDone);
    incentive = parseInt(incentive);
    minOrders = parseInt(minOrders);
    const todaysSal = parseInt(fixedSalary / 30);

    let incentiveToGive = 0;
    if (minOrders < employeeOrdersDone) {
      const diff = employeeOrdersDone - minOrders;
      incentiveToGive = incentive * diff;
    }
    const Total = todaysSal + incentiveToGive;

    const employeeInfoObj = {
      employeeName,
      employeeOrdersDone,
      employeeSalaryType,
      incentiveToGive,
      Total,
    };
    employeeInfo.push(employeeInfoObj);
    this.setState({
      employeeInfo,
    });

    e.target.reset();
  };

  renderTable2 = () => {
    const employeeInfo = this.state.employeeInfo;
    const data = employeeInfo.map((d, i) => {
      return (
        <tr key={i}>
          <td>{i + 1}</td>
          <td>{d.employeeName}</td>
          <td>{d.employeeSalaryType}</td>
          <td>{d.employeeOrdersDone}</td>
          <td>{d.incentiveToGive}</td>
          <td>{d.Total}</td>
        </tr>
      );
    });
    return data;
  };

  render() {
    return (
      <React.Fragment>
        <div>
          <h1>Salary App</h1>
          <h3>Salary info</h3>
          <form onSubmit={this.submitForm}>
            <MyInput
              name="salaryTypeName"
              value={this.state.salaryTypeName}
              title="Salary Type Name"
              Change={this.textChange}
            />
            <MyInput
              name="fixedSalary"
              value={this.state.fixedSalary}
              title="Fixed Salary"
              Change={this.textChange}
            />
            <MyInput
              name="incentive"
              value={this.state.incentive}
              title="Incentive"
              Change={this.textChange}
            />
            <MyInput
              name="minOrders"
              value={this.state.minOrders}
              title="Min Orders"
              Change={this.textChange}
            />
            <button type="submit">Submit</button>
          </form>
          <table>
            <thead>
              <tr>
                <th>Sr.No</th>
                <th>Salary Type Name</th>
                <th>Fixed Salary</th>
                <th>Incentive</th>
                <th>Min Orders</th>
              </tr>
            </thead>
            <tbody>{this.renderTable1()}</tbody>
          </table>
        </div>
        <div>
          <h2>Employee Info</h2>
          <form onSubmit={this.submitEmployeeForm}>
            <MyInput
              name="employeeName"
              value={this.state.employeeName}
              title="Employee Name"
              Change={this.textChange}
            />

            <MyInput
              name="employeeOrdersDone"
              value={this.state.employeeOrdersDone}
              title="Employee Orders done"
              Change={this.textChange}
            />

            <select
              name="employeeSalaryType"
              value={this.state.employeeSalaryType}
              className="form-control"
              onChange={this.textChange}
            >
              <option>No Salary Type</option>
              {this.renderSalaryType()}
            </select>
            <br />
            <button type="submit" className="btn btn-primary">
              Submit
            </button>
          </form>
          <table>
            <thead>
              <tr>
                <th>Sr.No</th>
                <th>Employee Name</th>
                <th>Salary Type Name</th>
                <th>Orders Done</th>
                <th>Incentive</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>{this.renderTable2}</tbody>
          </table>
        </div>
      </React.Fragment>
    );
  }
}

const MyInput = (props) => {
  return (
    <div>
      <label htmlFor={props.name}>{props.title}</label>
      <input
        type="text"
        id={props.name}
        name={props.name}
        value={props.theValue}
        onChange={props.Change}
      />
    </div>
  );
};

export default SalaryApp;
