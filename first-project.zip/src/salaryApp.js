import React from "react";

class App extends React.Component {
  constructor() {
    super();

    this.state = {
      salaryInfo: [],
      salaryTypeName: "",
      fixedSalary: "",
      incentive: "",
      minOrders: "",
      employeeInfo: [],
      employeeName: "",
      employeeOrdersDone: "",
      employeeSalaryType: "No Salary Type",
    };
  }

  submitEmployeeForm(e) {
    e.preventDefault();
    let {
      employeeName,
      employeeOrdersDone,
      employeeSalaryType,
      employeeInfo,
      salaryInfo,
    } = this.state;
    if (employeeSalaryType === "No Salary Type") {
      return console.log("Select a valid salary type");
    }
    let fixedSalary;
    let incentive;
    let minOrders;
    var data;
    for (data of salaryInfo) {
      console.log(data.salaryTypeName, employeeSalaryType);
      if (data.salaryTypeName === employeeSalaryType) {
        fixedSalary = data.fixedSalary;
        console.log(fixedSalary);
        incentive = data.incentive;
        minOrders = data.minOrders;
        break;
      }
    }
    fixedSalary = parseInt(fixedSalary);
    console.log(fixedSalary);
    employeeOrdersDone = parseInt(employeeOrdersDone);
    incentive = parseInt(incentive);
    minOrders = parseInt(minOrders);
    const todaysSal = parseInt(fixedSalary / 30);
    console.log(todaysSal);
    let incentiveToGive = 0;
    if (minOrders < employeeOrdersDone) {
      const diff = employeeOrdersDone - minOrders;
      incentiveToGive = incentive * diff;
    }
    const Total = todaysSal + incentiveToGive;

    const employeeInfoObj = {
      employeeName,
      employeeOrdersDone,
      employeeSalaryType,
      incentiveToGive,
      Total,
    };
    console.log(todaysSal);
    console.log(incentiveToGive);
    console.log(employeeInfoObj);

    employeeInfo.push(employeeInfoObj);
    this.setState({
      employeeInfo,
    });

    e.target.reset();
  }

  submitForm(e) {
    e.preventDefault();
    const {
      salaryTypeName,
      fixedSalary,
      incentive,
      minOrders,
      salaryInfo,
    } = this.state;
    const salaryInfoObj = {
      salaryTypeName,
      fixedSalary,
      incentive,
      minOrders,
    };

    salaryInfo.push(salaryInfoObj);
    this.setState({
      salaryInfo,
    });
    console.log(salaryInfo);
    e.target.reset();
  }

  textChange(e) {
    console.log(e.target.value);
    this.setState({
      [e.target.name]: e.target.value,
    });
  }

  renderTable1() {
    const salaryInfo = this.state.salaryInfo;
    const data = salaryInfo.map((d, i) => {
      return (
        <tr key={i}>
          <td>{i + 1}</td>
          <td> {d.salaryTypeName}</td>
          <td>{d.fixedSalary}</td>
          <td>{d.incentive}</td>
          <td>{d.minOrders}</td>
        </tr>
      );
    });
    return data;
  }

  renderTable2() {
    const employeeInfo = this.state.employeeInfo;
    const data = employeeInfo.map((d, i) => {
      return (
        <tr key={i}>
          <td>{i + 1}</td>
          <td>{d.employeeName}</td>
          <td>{d.employeeSalaryType}</td>
          <td>{d.employeeOrdersDone}</td>
          <td>{d.incentiveToGive}</td>
          <td>{d.Total}</td>
        </tr>
      );
    });
    return data;
  }

  renderSalaryType() {
    const salaryInfo = this.state.salaryInfo;
    const data = salaryInfo.map((d, i) => {
      return (
        <option value={d.salaryTypeName} key={i}>
          {d.salaryTypeName}
        </option>
      );
    });
    return data;
  }

  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-sm-6">
            <h2>Salary Info</h2>
            <form onSubmit={this.submitForm.bind(this)}>
              <MyInput
                name="salaryTypeName"
                value={this.state.salaryTypeName}
                title="Salary Type Name"
                Change={this.textChange.bind(this)}
              />
              <MyInput
                name="fixedSalary"
                value={this.state.fixedSalary}
                title="Fixed Salary"
                Change={this.textChange.bind(this)}
              />
              <MyInput
                name="incentive"
                value={this.state.incentive}
                title="Incentive"
                Change={this.textChange.bind(this)}
              />
              <MyInput
                name="minOrders"
                value={this.state.minOrders}
                title="Min Orders"
                Change={this.textChange.bind(this)}
              />

              <button type="submit" className="btn btn-primary">
                Submit
              </button>
            </form>
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>Sr.No</th>
                  <th>Salary Type Name</th>
                  <th>Fixed Salary</th>
                  <th>Incentive</th>
                  <th>Min Orders</th>
                </tr>
              </thead>
              <tbody>{this.renderTable1()}</tbody>
            </table>
          </div>

          <div className="col-sm-6">
            <h2>Employee Info</h2>

            <form onSubmit={this.submitEmployeeForm.bind(this)}>
              <MyInput
                name="employeeName"
                value={this.state.employeeName}
                title="Employee Name"
                Change={this.textChange.bind(this)}
              />

              <MyInput
                name="employeeOrdersDone"
                value={this.state.employeeOrdersDone}
                title="Employee Orders done"
                Change={this.textChange.bind(this)}
              />

              <select
                name="employeeSalaryType"
                value={this.state.employeeSalaryType}
                className="form-control"
                onChange={this.textChange.bind(this)}
              >
                <option>No Salary Type</option>
                {this.renderSalaryType()}
              </select>
              <br />
              <button type="submit" className="btn btn-primary">
                Submit
              </button>
            </form>
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>Sr.No</th>
                  <th>Employee Name</th>
                  <th>Salary Type Name</th>
                  <th>Orders Done</th>
                  <th>Incentive</th>
                  <th>Total</th>
                </tr>
              </thead>
              <tbody>{this.renderTable2()}</tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }
}

const MyInput = (props) => {
  return (
    <div className="form-group">
      <label htmlFor={props.name}>{props.title}:</label>
      <input
        required
        type="text"
        className="form-control"
        id={props.name}
        name={props.name}
        value={props.theValue}
        onChange={props.Change}
      />
    </div>
  );
};

export default App;
