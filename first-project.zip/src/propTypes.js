import React from "react";
import PropTypes from "prop-types";
import { Container } from "@material-ui/core";

class PropTypesExample extends React.Component {
  static defaultProps = {
    arrayProp: ["ram", "jay"],
    stringProp: "Dhruvit Vachhani",
    numberProp: "99",
    boolProp: true,
  };

  render() {
    return (
      <React.Fragment>
        <h1 align="center">PropTypes Example</h1>
        <Container>
          <h1>
            {this.props.arrayProp} {/*props name*/}
            <br />
            {this.props.stringProp}
            <br />
            {this.props.numberProp}
            <br />
            {this.props.boolProp}
            <br />
          </h1>
        </Container>
      </React.Fragment>
    );
  }
}

PropTypesExample.propTypes = {
  arrayProp: PropTypes.array,
  stringProp: PropTypes.string,
  numberProp: PropTypes.number,
  boolProp: PropTypes.bool,
};

// PropTypesExample.defaultProps = {
//   arrayProp: ["ram", "jay"],
//   stringProp: "Dhruvit",
//   numberProp: "99",
//   boolProp: true,
// };

export default PropTypesExample;
