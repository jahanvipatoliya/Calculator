import React from "react";
import subCategory from "./subcategory.json";

class SortingArrayFormat extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: subCategory.Categories,
      filtered_category_list: [],
      category_list: [],
    };
  }

  componentDidMount = () => {
    var maincat = [];
    var maincatlist = [];

    this.state.data.map((item, i) => {
      const categoryLists = {
        CategoryID: item.CategoryID,
        title: item.Category,
      };

      maincat[item.CategoryID] = categoryLists;
      maincat.map((main, i) => {
        var categoryList = this.state.data;
        var Categories = categoryList
          .filter((item) => item.Category === main.title)
          .map(({ SubCategoryID, SubCategoryName }) => ({
            SubCategoryID,
            SubCategoryName,
          }));

        var mlist = {
          title: main.title,
          list: Categories,
        };

        maincatlist[main.CategoryID] = mlist;
        return main;
      });
      this.setState({
        filtered_category_list: maincatlist,
        category_list: maincatlist,
      });
      return item;
    });
  };
  render() {
    console.log(this.state.filtered_category_list);
    return (
      <React.Fragment>
        {this.state.filtered_category_list.map((val, index) => {
          return (
            <>
              <h3>{val.title}</h3>
              {val.list.map((subval, i) => {
                return <p>{subval.SubCategoryName}</p>;
              })}
            </>
          );
        })}
      </React.Fragment>
    );
  }
}

export default SortingArrayFormat;
