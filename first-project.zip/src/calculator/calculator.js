import React from "react";
import { Container } from "@material-ui/core";
import Button from "./Button";
import OutputScreen from "./outputScreen";
import { Helmet } from "react-helmet";

class CalculatorExample extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      question: "",
      answer: "",
    };
  }

  handleClick = (event) => {
    const value = event.target.value;

    switch (value) {
      case "=": {
        if (this.state.question !== "") {
          var ans = "";
          try {
            ans = eval(this.state.question);
          } catch (err) {
            this.setState({ answer: "Math Error" });
          }
          if (ans === undefined) this.setState({ answer: "Math Error" });
          //update answer in our state
          else this.setState({ answer: ans, question: "" });
          break;
        }
      }

      case "Clear": {
        this.setState({ question: "", answer: "" });
        break;
      }

      case "Delete": {
        var str = this.state.question;
        str = str.substr(0, str.length - 1);
        this.setState({ question: str });
        break;
      }

      default: {
        let quest = this.state.question;
        this.setState({ question: (quest += value) });
        break;
      }
    }
  };

  render() {
    const operationArr = ["Clear", "Delete", ".", "/", "*", "-", "+", "="];
    const buttnArr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0];
    return (
      <React.Fragment>
        <Helmet>
          <title>Calculator</title>
        </Helmet>
        <Container align="center">
          <h2>React Calculator</h2>
          <br />
          <OutputScreen
            question={this.state.question}
            answer={this.state.answer}
          />
          <br />
          <div>
            {operationArr.map((opt, i) => {
              return (
                <>
                  <Button
                    key={opt}
                    handleClick={() => this.handleClick}
                    label={opt}
                  />
                  &nbsp;
                </>
              );
            })}
          </div>
          <br />
          <div>
            {buttnArr.map((val, index) => {
              return (
                <>
                  <Button
                    key={val}
                    handleClick={() => this.handleClick}
                    label={val}
                  />
                  &nbsp;{index % 3 === 0 ? <br /> : null}
                </>
              );
            })}
          </div>
        </Container>
      </React.Fragment>
    );
  }
}

export default CalculatorExample;
