import React from "react";

class ToggleDiv extends React.Component {
  constructor() {
    super();
    this.state = {
      show: true,
    };
  }
  render() {
    return (
      <div>
        {this.state.show ? (
          <div>
            <h2 style={{ textAlign: "center" }}>Toggle Div</h2>
          </div>
        ) : null}
        <button
          onClick={() => {
            this.setState({ show: !this.state.show });
          }}
        >
          {this.state.show ? "Hide" : "Show"} Div
        </button>
      </div>
    );
  }
}

export default ToggleDiv;
