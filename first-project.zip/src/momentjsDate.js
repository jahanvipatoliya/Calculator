import { Container } from "@material-ui/core";
import React from "react";
import TextField from "@material-ui/core/TextField";
import moment from "moment";

class MomentDateExa extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedDate: "",
      age: "",
    };
  }

  changeHandler = (e) => {
    const { value } = e.target;
    this.setState({ selectedDate: value });
  };

  submitHandler = (e) => {
    e.preventDefault();
    var today = moment(new Date());
    var sdate = moment(new Date(this.state.selectedDate));
    const diffdate = today.diff(sdate, "year");
    this.setState({ age: diffdate });
  };
  render() {
    return (
      <React.Fragment>
        <Container align="center">
          <h1>MomentJS Days Counting</h1>
          <br />
          <form onSubmit={this.submitHandler}>
            <TextField
              id="date"
              label="Birthday"
              type="date"
              name="selectedDate"
              onChange={this.changeHandler}
              value={this.state.selectedDate}
              defaultValue="2021-01-15"
              formatDate={(date) => moment(date).format("DD-MM-YYYY")}
              InputLabelProps={{
                shrink: true,
              }}
            />
            <br />
            <br />
            <button type="submit">Submit</button>
          </form>
          <h3>Your Age is:{this.state.age}</h3>
        </Container>
      </React.Fragment>
    );
  }
}

export default MomentDateExa;
