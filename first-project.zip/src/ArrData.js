export const ArrData = [
    {
        "title": "Home & Utilities",
        "list": [
            {
                "SubCategoryID": 1,
                "SubCategoryName": "Mortgage & rent"
            },
            {
                "SubCategoryID": 2,
                "SubCategoryName": "Body corporate fees"
            },
        ]
    },
    {
        "title": "Groceries",
        "list": [
            {
                "SubCategoryID": 26,
                "SubCategoryName": "Supermarket"
            },
            {
                "SubCategoryID": 27,
                "SubCategoryName": "Butcher"
            },
        ]
    },
    {
        "title": "Personal & Medical",
        "list": [
            {
                "SubCategoryID": 33,
                "SubCategoryName": "Cosmetics & toiletries"
            },
            {
                "SubCategoryID": 34,
                "SubCategoryName": "Hair & beauty"
            },
        ]
    },
    {
        "title": "Entertainment & Eat-out",
        "list": [
            {
                "SubCategoryID": 47,
                "SubCategoryName": "Coffee & tea"
            },
            {
                "SubCategoryID": 48,
                "SubCategoryName": "Lunches - bought"
            },
        ]
    },
    {
        "title": "Transport & Auto",
        "list": [
            {
                "SubCategoryID": 60,
                "SubCategoryName": "Bus & train & ferry"
            },
            {
                "SubCategoryID": 61,
                "SubCategoryName": "Petrol"
            },
        ]
    },
]