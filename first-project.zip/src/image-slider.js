import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./css/slider.css";
import { Helmet } from "react-helmet";

class ImageSliderExample extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      imagesData: [
        { id: 1, img: "http://placekitten.com/g/200/300" },
        { id: 2, img: "http://placekitten.com/g/400/300" },
        { id: 3, img: "http://placekitten.com/g/500/300" },
      ],
    };
  }

  render() {
    const settings = {
      dots: true,
      infinite: true,
      speed: 300,
      slidesToShow: 1,
      slidesToScroll: 1,
      className: "slider",
    };
    return (
      <div>
        <Helmet>
          <title>Image Slider</title>
        </Helmet>
        <Slider {...settings}>
          {this.state.imagesData.map((val, index) => (
            <div>
              <img key={val.id} src={val.img} alt={val.id} />
            </div>
          ))}
        </Slider>
      </div>
    );
  }
}

const ImgSlider = () => {
  return (
    <>
      <ImageSliderExample />
    </>
  );
};

export default ImgSlider;
