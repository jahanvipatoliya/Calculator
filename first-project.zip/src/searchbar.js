import { Container } from "@material-ui/core";
import React from "react";
import fruit from "./checkboxArray.json";

class SearchBar extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      searchName: "",
      data: fruit,
      items: [],
    };
  }

  changeHandler = (e) => {
    // this.state({ searchName: e.target.value });
    var updatedList = this.state.data;
    updatedList = updatedList.filter((item) => {
      return (
        item.name.toLowerCase().search(e.target.value.toLowerCase()) !== -1
      );
    });
    this.setState({ items: updatedList });
  };

  componentWillMount = () => {
    this.setState({
      items: this.state.data,
    });
  };

  render() {
    const { searchName, data } = this.state;

    return (
      <React.Fragment>
        <Container align="center">
          <h1>Search from array</h1>
          <form>
            <label>
              Search Fruit :&nbsp;
              <input
                type="text"
                name="text"
                placeholder="search"
                onChange={this.changeHandler}
              />
            </label>
            <input type="submit" value="submit" />
          </form>
          <List items={this.state.items} />
        </Container>
      </React.Fragment>
    );
  }
}

class List extends React.Component {
  render() {
    return (
      <div>
        {this.props.items.map((val, index) => {
          return <p>{val.name}</p>;
        })}
      </div>
    );
  }
}

export default SearchBar;
