import React from "react";
import { BrowserRouter as Router } from "react-router-dom";
import { Route, Switch, Link } from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import IconButton from "@material-ui/core/IconButton";
import "./css/menubar.css";
import Table from "./table";
import ArrayTest from "./2ndReact";
import Form from "./form";
import ModalExample from "./modal";
import Tabs from "./tabs";
import AccordianE from "./accordian";
import TemporaryDrawer from "./drawer";
import DropDownSearch from "./dropdownSearch";
import SteppersExample from "./steppers";
import ImageSliderExample from "./image-slider";
import ToDoList from "./ToDoList/toDoList";
import PaginationEx from "./pagination";
import Counter from "./counter";
import Calculator from "./calculator/calculator";

class MenuBar extends React.Component {
  useStyles = makeStyles((theme) => ({
    root: {
      flexGrow: 1,
    },
    menuButton: {
      marginRight: theme.spacing(2),
    },
    title: {
      flexGrow: 1,
    },
  }));
  render() {
    const classes = this.useStyles;
    return (
      <div>
        <div className={classes.root}>
          <Router>
            <AppBar position="static">
              <Toolbar>
                <IconButton
                  edge="start"
                  className={classes.menuButton}
                  color="inherit"
                  aria-label="menu"
                >
                  <TemporaryDrawer />
                </IconButton>
                <Typography variant="h6" className={classes.title}>
                  React Router
                </Typography>

                <Button color="inherit">
                  <Link to="/">Home</Link>
                </Button>
                <Button>
                  <Link to="/array-list">Array LIst</Link>
                </Button>
                <Button>
                  <Link to="/pagination">Pagination</Link>
                </Button>
                <Button>
                  <Link to="/calculator">Calculator</Link>
                </Button>
                <Button>
                  <Link to="/form">Form</Link>
                </Button>
                <Button>
                  <Link to="/modal">Modal</Link>
                </Button>
                <Button>
                  <Link to="/tabs">Tabs</Link>
                </Button>
                <Button>
                  <Link to="/accordian">Accordian</Link>
                </Button>
                <Button>
                  <Link to="/drop-down-search">D-D Search</Link>
                </Button>
                <Button>
                  <Link to="/stepper">Stepper</Link>
                </Button>
                <Button>
                  <Link to="/image-slider">Image Slider</Link>
                </Button>
                <Button>
                  <Link to="/to-do-list">ToDoList</Link>
                </Button>
                <Button>
                  <Link to="/counter">Counter</Link>
                </Button>
              </Toolbar>
            </AppBar>
            <Switch>
              <Route exact path="/" component={Home} />

              <Route path="/array-list" component={ArrayList} />
              <Route path="/pagination" component={PaginationsExample} />
              <Route path="/calculator" component={CalcApp} />
              <Route path="/form" component={FormData} />
              <Route path="/modal" component={ModalExa} />
              <Route path="/tabs" component={TabExa} />
              <Route path="/accordian" component={AccordianExa} />
              <Route path="/drop-down-search" component={DropDownSearchExa} />
              <Route path="/stepper" component={StepperEx} />
              <Route path="/image-slider" component={ImageSliderExaa} />
              <Route path="/to-do-list" component={ToDoListData} />
              <Route path="/counter" component={CounterExa} />
            </Switch>
          </Router>
        </div>
      </div>
    );
  }
}

// components for Switch Route

const Home = () => <p>Home page content goes here!!!</p>;

const ArrayList = () => <ArrayTest />;
const FormData = () => <Form />;
const ModalExa = () => <ModalExample />;
const TabExa = () => <Tabs />;
const AccordianExa = () => <AccordianE />;
const DropDownSearchExa = () => <DropDownSearch />;
const StepperEx = () => <SteppersExample />;
const ImageSliderExaa = () => <ImageSliderExample />;
const ToDoListData = () => <ToDoList />;
const PaginationsExample = () => <PaginationEx />;
const CounterExa = () => <Counter />;
const CalcApp = () => <Calculator />;

export default MenuBar;
