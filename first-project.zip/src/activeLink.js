import { useStyles } from "@material-ui/pickers/views/Calendar/SlideTransition";
import React from "react";
import {
  BrowserRouter as Router,
  Route,
  NavLink,
  Switch,
} from "react-router-dom";
import { makeStyles } from "@material-ui/core/styles";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import IconButton from "@material-ui/core/IconButton";
import MenuIcon from "@material-ui/icons/Menu";
import "./css/activeMenu.css";
import link from "./activelink.json";

class ActiveLink extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      clickedItemVal: "",
    };
  }
  useStyles = makeStyles((theme) => ({
    root: {
      flexGrow: 1,
    },
    menuButton: {
      marginRight: theme.spacing(2),
    },
    title: {
      flexGrow: 1,
    },
  }));

  changeHandler = (val) => {
    this.setState({
      //   color: "black",
      clickedItemVal: val,
    });
  };

  render() {
    const classes = useStyles;
    let inputStyle = this.state.color;
    var { clickedItemVal } = this.state;
    return (
      <React.Fragment>
        <br />
        <div className={classes.root}>
          <AppBar position="static">
            <Toolbar>
              <IconButton
                edge="start"
                className={classes.menuButton}
                color="inherit"
                aria-label="menu"
              >
                <MenuIcon />
              </IconButton>
              <Typography variant="h6" className={classes.title}>
                Links
              </Typography>
              <Router className="menu-bar">
                {link.map((val, index) => {
                  return (
                    <Button>
                      <li>
                        <NavLink
                          className={
                            clickedItemVal.name === val.name
                              ? " activeLink"
                              : ""
                          }
                          style={this.state}
                          to={val.path}
                          onClick={() => this.changeHandler(val)}
                        >
                          {val.name}
                        </NavLink>
                      </li>
                    </Button>
                  );
                })}
              </Router>
            </Toolbar>
          </AppBar>
        </div>
      </React.Fragment>
    );
  }
}

export default ActiveLink;
