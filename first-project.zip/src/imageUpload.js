import React from "react";

class ImageUpload extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      file: "",
      imgPreviewUrl: "",
    };
  }
  getInitialState = () => {
    return { file: [] };
  };

  changeHandler = (e) => {
    e.preventDefault();

    let reader = new FileReader();
    let file = e.target.files[0];

    reader.onloadend = () => {
      this.setState({
        file: file,
        imgPreviewUrl: reader.result,
      });
    };
    reader.readAsDataURL(file);
  };

  submitHandler = (e) => {
    e.prevenyDefault();
    console.log("handle uploading", this.state.file);
  };

  render() {
    let { imgPreviewUrl } = this.state;
    let $imgPreview = null;
    if (imgPreviewUrl) {
      $imgPreview = <img src={imgPreviewUrl} />;
    } else {
      $imgPreview = <div>Please select an image for preview</div>;
    }
    return (
      <div>
        <h1 align="center">Image Upload and Preview</h1>
        <div>
          <form onSubmit={this.submitHandler}>
            <input type="file" onChange={this.changeHandler} multiple />
            <button type="submit">Upload Image</button>
          </form>

          <br />
          <br />
          <div>{$imgPreview}</div>
        </div>
      </div>
    );
  }
}

export default ImageUpload;
