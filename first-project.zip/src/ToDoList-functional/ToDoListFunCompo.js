import { makeStyles } from "@material-ui/core";
import React, { useState } from "react";
import InputLabel from "@material-ui/core/InputLabel";
import MenuItem from "@material-ui/core/MenuItem";
import TextField from "@material-ui/core/TextField";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import Alert from "@material-ui/lab/Alert";
import Button from "@material-ui/core/Button";
import TableToDoList from "./tableFunCompo";
import IconButton from "@material-ui/core/IconButton";
import OutlinedInput from "@material-ui/core/OutlinedInput";
import InputAdornment from "@material-ui/core/InputAdornment";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";
import "../css/form.css";

const useStyle = makeStyles((theme) => ({
  root: {
    "& > *": {
      margin: theme.spacing(1),
      width: "25ch",
    },
  },
  withoutLabel: {
    marginTop: theme.spacing(3),
  },
  margin: {
    margin: theme.spacing(1),
  },
  formControl: {
    margin: theme.spacing(1),
    minWidth: 120,
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));

const ToDoListFunCompo = () => {
  const classes = useStyle();

  const [list, setList] = useState([]);
  const [input, setInput] = useState({});
  const [count, setCount] = useState(1);
  const [errors, setErrors] = useState({});
  const [showPwd, setShowpwd] = useState({
    showPassword: false,
    showConfPassword: false,
  });
  const [submitBtn, setSubmitBtn] = useState(true);
  const [updateBtn, setUpdateBtn] = useState(false);

  //show password
  const handleClickShowPassword = () => {
    setShowpwd({ ...showPwd, showPassword: !showPwd.showPassword });
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };
  // show confirm password
  const handleClickShowConfPassword = () => {
    setShowpwd({ ...showPwd, showConfPassword: !showPwd.showConfPassword });
  };

  const handleMouseDownConfPassword = (event) => {
    event.preventDefault();
  };

  const changeHandler = (e) => {
    const { name, value } = e.target;
    setInput({ ...input, [name]: value });
  };

  const SubmitHandler = (e) => {
    e.preventDefault();
    var inputVal = input;

    inputVal = {
      id: count,
      country: input.country,
      phone: input.phone,
      name: input.name,
      email: input.email,
      password: input.password,
      repeat_password: input.repeat_password,
    };

    const flagData = isValidate();

    if (flagData) {
      list.push(inputVal);
      setCount((prevCount) => {
        return prevCount + 1;
      });
      setInput({
        id: "",
        country: "",
        phone: "",
        name: "",
        email: "",
        password: "",
        repeat_password: "",
      });
    }
  };

  //error validation
  const isValidate = () => {
    var val = input;
    let errors = {};
    let flag = true;

    if (!val.country) {
      errors.country = "country is required";
      flag = false;
    }
    if (!val.phone) {
      errors.phone = "phone is required";
      flag = false;
    }
    if (typeof val.email !== "") {
      var pattern = new RegExp(
        /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
      );
      if (!pattern.test(val.email)) {
        errors.email = "Please enter valid email address.";
        flag = false;
      }
    }
    if (!val.name) {
      errors.name = "name is required";
      flag = false;
    }
    if (!val.password) {
      errors.password = "password is required";
      flag = false;
    }
    if (!val.repeat_password) {
      errors.repeat_password = "confirm password is required";
      flag = false;
    }
    if (val.password && val.repeat_password) {
      if (val.password !== val.repeat_password) {
        errors.password = "Passwords don't match.";
        flag = false;
      }
    }
    setErrors(errors);
    return flag;
  };

  const DeleteRowItem = (selecteditem) => {
    let filteredArray = list.filter((item) => item.id != selecteditem.id);
    setList(filteredArray);
  };

  const editItem = (val, i) => {
    setInput({
      id: val.id,
      country: val.country,
      phone: val.phone,
      name: val.name,
      email: val.email,
      password: val.password,
      repeat_password: val.repeat_password,
    });
    setUpdateBtn(true);
    setSubmitBtn(false);
  };

  const updateItem = (e) => {
    if (isValidate()) {
      let updateList = list.map((updatedUser) => {
        if (updatedUser.id == input.id) {
          updatedUser.country = input.country;
          updatedUser.phone = input.phone;
          updatedUser.name = input.name;
          updatedUser.email = input.email;
          updatedUser.password = input.password;
          updatedUser.repeat_password = input.repeat_password;
        }
        return updatedUser;
      });
      setInput({
        id: "",
        country: "",
        phone: "",
        name: "",
        email: "",
        password: "",
        repeat_password: "",
      });
      setList(updateList);
      setUpdateBtn(false);
      setSubmitBtn(true);
    }
  };

  return (
    <React.Fragment>
      <div>
        <div className="container_form">
          <form className={classes.root} onSubmit={(e) => SubmitHandler(e)}>
            <br />
            <FormControl variant="outlined" className={classes.formControl}>
              <InputLabel id="demo-simple-select-outlined-label">
                Country
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                onChange={(e) => changeHandler(e)}
                name="country"
                label="Country"
              >
                <MenuItem name="australia" value="australia">
                  Australia
                </MenuItem>
                <MenuItem name="india" value="india">
                  India
                </MenuItem>
                <MenuItem name="newzealand" value="newzealand">
                  NewZealand
                </MenuItem>
                <MenuItem name="singapore" value="singapore">
                  Singapore
                </MenuItem>
              </Select>
              <div>
                {errors.country ? (
                  <Alert severity="error">{errors.country}</Alert>
                ) : null}
              </div>
              <br />
              <TextField
                id="outlined-phone"
                label="Your Phone Number"
                variant="outlined"
                name="phone"
                helperText=""
                value={input.phone}
                onChange={(e) => changeHandler(e)}
              />

              <div>
                {errors.phone ? (
                  <Alert severity="error">{errors.phone}</Alert>
                ) : null}
              </div>
              <br />
              <TextField
                id="outlined-name"
                label="Name"
                name="name"
                variant="outlined"
                value={input.name}
                onChange={(e) => changeHandler(e)}
              />
              <div>
                {errors.name ? (
                  <Alert severity="error">{errors.name}</Alert>
                ) : null}
              </div>
              <br />
              <TextField
                id="outlined-email"
                label="Email"
                name="email"
                variant="outlined"
                value={input.email}
                onChange={(e) => changeHandler(e)}
              />
              <div>
                {errors.email ? (
                  <Alert severity="error">{errors.email}</Alert>
                ) : null}
              </div>
              <br />
              <FormControl variant="outlined">
                <InputLabel htmlFor="outlined-adornment-password">
                  Password
                </InputLabel>
                <OutlinedInput
                  id="outlined-adornment-password"
                  type={showPwd.showPassword ? "text" : "password"}
                  name="password"
                  value={input.password}
                  onChange={(e) => changeHandler(e)}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleClickShowPassword}
                        onMouseDown={handleMouseDownPassword}
                        edge="end"
                      >
                        {showPwd.showPassword ? (
                          <Visibility />
                        ) : (
                          <VisibilityOff />
                        )}
                      </IconButton>
                    </InputAdornment>
                  }
                  labelWidth={70}
                />
              </FormControl>
              <div>
                {errors.password ? (
                  <Alert severity="error">{errors.password}</Alert>
                ) : null}
              </div>
              <br />
              <FormControl variant="outlined">
                <InputLabel htmlFor="outlined-adornment-password">
                  Confirm Password
                </InputLabel>
                <OutlinedInput
                  id="outlined-adornment-password"
                  type={showPwd.showConfPassword ? "text" : "password"}
                  name="repeat_password"
                  value={input.repeat_password}
                  onChange={(e) => changeHandler(e)}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={handleClickShowConfPassword}
                        onMouseDown={handleMouseDownConfPassword}
                        edge="end"
                      >
                        {showPwd.showConfPassword ? (
                          <Visibility />
                        ) : (
                          <VisibilityOff />
                        )}
                      </IconButton>
                    </InputAdornment>
                  }
                  labelWidth={70}
                />
              </FormControl>
              <div>
                {errors.repeat_password ? (
                  <Alert severity="error">{errors.repeat_password}</Alert>
                ) : null}
              </div>
              <br />
              {submitBtn ? (
                <Button type="submit" variant="contained" color="primary">
                  Submit
                </Button>
              ) : null}
              {updateBtn ? (
                <Button
                  onClick={updateItem}
                  variant="contained"
                  color="primary"
                >
                  Update
                </Button>
              ) : null}
            </FormControl>
          </form>
        </div>
        <br />
        <TableToDoList editItem={editItem} list={list} delRow={DeleteRowItem} />
      </div>
    </React.Fragment>
  );
};

export default ToDoListFunCompo;
