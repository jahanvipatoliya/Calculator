import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import InputLabel from "@material-ui/core/InputLabel";
import clsx from "clsx";
import MenuItem from "@material-ui/core/MenuItem";
import TextField from "@material-ui/core/TextField";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import Alert from "@material-ui/lab/Alert";
import Button from "@material-ui/core/Button";
import ToDoListTable from "./table";
import IconButton from "@material-ui/core/IconButton";
import OutlinedInput from "@material-ui/core/OutlinedInput";
import InputAdornment from "@material-ui/core/InputAdornment";
import Visibility from "@material-ui/icons/Visibility";
import VisibilityOff from "@material-ui/icons/VisibilityOff";
import Helmet from "react-helmet";
import "../css/form.css";

class ToDoList extends React.Component {
  constructor() {
    super();
    this.state = {
      list: [],
      input: {},
      errors: {},
      showPassword: false,
      showConfPassword: false,
      count: 1,
      submitBtn: true,
      updateBtn: false,
    };
  }

  changeHandler = (e) => {
    let input = this.state.input;
    input[e.target.name] = e.target.value;

    this.setState({
      input,
    });
  };

  SubmitHandler = (e) => {
    e.preventDefault();
    var input = this.state.input;
    this.setState((prevState) => {
      return { count: prevState.count + 1 };
    });
    input = {
      id: this.state.count,
      country: input.country,
      phone: input.phone,
      name: input.name,
      email: input.email,
      password: input.password,
      repeat_password: input.repeat_password,
    };

    var tempList = this.state.list;
    if (this.Validate()) {
      tempList.push(input);
      this.setState({
        input: {
          id: "",
          country: "",
          phone: "",
          name: "",
          email: "",
          password: "",
          repeat_password: "",
        },
        list: tempList,
      });
    }
  };

  Validate = () => {
    let input = this.state.input;
    let errors = {};
    let isValid = true;

    if (!input["country"]) {
      isValid = false;
      errors["country"] = "please select the country.";
    }

    if (!input["phone"]) {
      isValid = false;
      errors["phone"] = "please enter your phone.";
    }

    if (!input["name"]) {
      isValid = false;
      errors["name"] = "please enter your name.";
    }

    if (typeof input["email"] !== "") {
      var pattern = new RegExp(
        /^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i
      );
      if (!pattern.test(input["email"])) {
        isValid = false;
        errors["email"] = "Please enter valid email address.";
      }
    }

    if (!input["password"]) {
      isValid = false;
      errors["password"] = "please enter password.";
    }

    if (!input["repeat_password"]) {
      isValid = false;
      errors["repeat_password"] = "please enter confirm password.";
    }

    if (input["password"] && input["repeat_password"]) {
      if (input["password"] !== input["repeat_password"]) {
        isValid = false;
        errors["password"] = "Passwords don't match.";
      }
    }

    this.setState({
      errors: errors,
    });

    return isValid;
  };

  useStyles = makeStyles((theme) => ({
    root: {
      "& > *": {
        margin: theme.spacing(1),
        width: "25ch",
      },
    },
    withoutLabel: {
      marginTop: theme.spacing(3),
    },
    margin: {
      margin: theme.spacing(1),
    },
    formControl: {
      margin: theme.spacing(1),
      minWidth: 120,
    },
    selectEmpty: {
      marginTop: theme.spacing(2),
    },
  }));

  DeleteRowItem = (selecteditem) => {
    let filteredArray = this.state.list.filter(
      (item) => item.id !== selecteditem.id
    );
    this.setState({ list: filteredArray });
    console.log("DeleteRowItem", this.state.list);
  };

  editItem = (val, i) => {
    const input = this.state.input;
    this.setState({
      input: {
        id: val.id,
        country: val.country,
        phone: val.phone,
        name: val.name,
        email: val.email,
        password: val.password,
        repeat_password: val.repeat_password,
      },
      updateBtn: true,
      submitBtn: false,
    });
  };

  updateItem = (e) => {
    if (this.Validate()) {
      const { input } = this.state;
      let updateList = this.state.list.map((updatedUSer) => {
        if (updatedUSer.id === input.id) {
          updatedUSer.country = input.country;
          updatedUSer.phone = input.phone;
          updatedUSer.name = input.name;
          updatedUSer.email = input.email;
          updatedUSer.password = input.password;
          updatedUSer.repeat_password = input.repeat_password;
        }
        return updatedUSer;
      });
      this.setState({
        input: {
          id: "",
          country: "",
          phone: "",
          name: "",
          email: "",
          password: "",
          repeat_password: "",
        },
        list: updateList,
        updateBtn: false,
        submitBtn: true,
      });
    }
    e.preventDefault();
  };

  // password show
  handleClickShowPassword = () => {
    this.setState({
      ...this.state,
      showPassword: !this.state.showPassword,
    });
  };

  handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  // confirm password show
  handleClickShowConfPassword = (event) => {
    this.setState({
      ...this.state,
      showConfPassword: !this.state.showConfPassword,
    });
  };

  handleMouseDownconfPassword = (event) => {
    event.preventDefault();
  };

  render() {
    const classes = this.useStyles;
    return (
      <div>
        <Helmet>
          <title>To Do List</title>
        </Helmet>
        <div className="container_form">
          <form onSubmit={this.SubmitHandler} className={classes.root}>
            <br />
            <FormControl variant="outlined" className={classes.formControl}>
              <InputLabel id="demo-simple-select-outlined-label">
                Country
              </InputLabel>
              <Select
                labelId="demo-simple-select-outlined-label"
                id="demo-simple-select-outlined"
                onChange={this.changeHandler}
                name="country"
                label="Country"
              >
                <MenuItem name="australia" value="australia">
                  Australia
                </MenuItem>
                <MenuItem name="india" value="india">
                  India
                </MenuItem>
                <MenuItem name="newzealand" value="newzealand">
                  NewZealand
                </MenuItem>
                <MenuItem name="singapore" value="singapore">
                  Singapore
                </MenuItem>
              </Select>
              <div>
                {this.state.errors.country ? (
                  <Alert severity="error">{this.state.errors.country}</Alert>
                ) : null}
              </div>
              <br />
              <TextField
                id="outlined-phone"
                label="Your Phone Number"
                variant="outlined"
                name="phone"
                helperText=""
                value={this.state.input.phone}
                onChange={this.changeHandler}
              />

              <div>
                {this.state.errors.phone ? (
                  <Alert severity="error">{this.state.errors.phone}</Alert>
                ) : null}
              </div>
              <br />
              <TextField
                id="outlined-name"
                label="Name"
                name="name"
                variant="outlined"
                value={this.state.input.name}
                onChange={this.changeHandler}
              />
              <div>
                {this.state.errors.name ? (
                  <Alert severity="error">{this.state.errors.name}</Alert>
                ) : null}
              </div>
              <br />
              <TextField
                id="outlined-email"
                label="Email"
                name="email"
                variant="outlined"
                value={this.state.input.email}
                onChange={this.changeHandler}
              />
              <div>
                {this.state.errors.email ? (
                  <Alert severity="error">{this.state.errors.email}</Alert>
                ) : null}
              </div>
              <br />
              <FormControl
                className={clsx(classes.margin, classes.textField)}
                variant="outlined"
              >
                <InputLabel htmlFor="outlined-adornment-password">
                  Password
                </InputLabel>
                <OutlinedInput
                  id="outlined-adornment-password"
                  type={this.state.showPassword ? "text" : "password"}
                  name="password"
                  value={this.state.input.password}
                  onChange={this.changeHandler}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={this.handleClickShowPassword}
                        onMouseDown={this.handleMouseDownPassword}
                        edge="end"
                      >
                        {this.state.showPassword ? (
                          <Visibility />
                        ) : (
                          <VisibilityOff />
                        )}
                      </IconButton>
                    </InputAdornment>
                  }
                  labelWidth={70}
                />
              </FormControl>
              <div>
                {this.state.errors.password ? (
                  <Alert severity="error">{this.state.errors.password}</Alert>
                ) : null}
              </div>
              <br />
              <FormControl
                className={clsx(classes.margin, classes.textField)}
                variant="outlined"
              >
                <InputLabel htmlFor="outlined-adornment-password">
                  Confirm Password
                </InputLabel>
                <OutlinedInput
                  id="outlined-adornment-password"
                  type={this.state.showConfPassword ? "text" : "password"}
                  name="repeat_password"
                  value={this.state.input.repeat_password}
                  onChange={this.changeHandler}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        onClick={this.handleClickShowConfPassword}
                        onMouseDown={this.handleMouseDownconfPassword}
                        edge="end"
                      >
                        {this.state.showConfPassword ? (
                          <Visibility />
                        ) : (
                          <VisibilityOff />
                        )}
                      </IconButton>
                    </InputAdornment>
                  }
                  labelWidth={70}
                />
              </FormControl>
              <div>
                {this.state.errors.repeat_password ? (
                  <Alert severity="error">
                    {this.state.errors.repeat_password}
                  </Alert>
                ) : null}
              </div>
              <br />
              {this.state.submitBtn ? (
                <Button type="submit" variant="contained" color="primary">
                  Submit
                </Button>
              ) : null}
              {this.state.updateBtn ? (
                <Button
                  onClick={this.updateItem}
                  variant="contained"
                  color="primary"
                >
                  Update
                </Button>
              ) : null}
            </FormControl>
          </form>
        </div>
        <br />
        <ToDoListTable
          editItem={this.editItem}
          list={this.state.list}
          delRow={this.DeleteRowItem}
        />
      </div>
    );
  }
}

export default ToDoList;
