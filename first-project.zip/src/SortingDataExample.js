import React from "react";

class SortingExample extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      users: [
        {
          id: 1,
          UserFullName: "jnext",
          UserBirthDate: null,
          UserCurrencyCode: "IND",
          UserGender: null,
          UserPhone: "9876543210",
          UserEmail: "jnext@gmail.com",
        },
        {
          id: 2,
          UserFullName: "Dhruvit",
          UserBirthDate: null,
          UserCurrencyCode: "IND",
          UserGender: "male",
          UserPhone: "9998299775",
          UserEmail: "vachhanidhruvit@gmail.com",
        },
        {
          id: 3,
          UserFullName: "vachhani",
          UserBirthDate: null,
          UserCurrencyCode: "IND",
          UserGender: "male",
          UserPhone: "1234567890",
          UserEmail: "test@gmail.com",
        },
        {
          id: 4,
          UserFullName: "steave",
          UserBirthDate: null,
          UserCurrencyCode: "IND",
          UserGender: "male",
          UserPhone: "9998887776",
          UserEmail: "sortingdata@gmail.com",
        },
        {
          id: 5,
          UserFullName: "mark",
          UserBirthDate: null,
          UserCurrencyCode: "IND",
          UserGender: "male",
          UserPhone: "8887779999",
          UserEmail: "lbwe@gmail.com",
        },
        {
          id: 6,
          UserFullName: "ivanka",
          UserBirthDate: null,
          UserCurrencyCode: "IND",
          UserGender: "female",
          UserPhone: "777881111",
          UserEmail: "hello.in@gmail.com",
        },
        {
          id: 7,
          UserFullName: "hello bean",
          UserBirthDate: null,
          UserCurrencyCode: "IND",
          UserGender: null,
          UserPhone: "666888772",
          UserEmail: "kkkll@gmail.com",
        },
        {
          id: 8,
          UserFullName: "jaay",
          UserBirthDate: null,
          UserCurrencyCode: "IND",
          UserGender: "male",
          UserPhone: "971564144",
          UserEmail: "hellogm@gmail.com",
        },
        {
          id: 9,
          UserFullName: "games",
          UserBirthDate: null,
          UserCurrencyCode: "IND",
          UserGender: "female",
          UserPhone: "3322111447",
          UserEmail: "vachhani@gmail.com",
        },
        {
          id: 10,
          UserFullName: "Srk One",
          UserBirthDate: null,
          UserCurrencyCode: "IND",
          UserGender: null,
          UserPhone: "7777788888",
          UserEmail: "dhruvit@gmail.com",
        },
      ],
    };
  }

  render() {
    const group = this.state.users
      .sort((a, b) =>
        a.UserFullName.toUpperCase().localeCompare(b.UserFullName.toUpperCase())
      )
      .reduce((r, e) => {
        const key = e.UserFullName.toUpperCase()[0];
        if (!r[key]) r[key] = [];
        r[key].push(e);
        return r;
      }, {});

    return (
      <React.Fragment>
        <div>
          {Object.entries(group).map(([key, value], i) => {
            return (
              <div key={i}>
                {value.length > 0 && (
                  <>
                    <h3>{key}</h3>
                    {value.map((item, j) => {
                      return <p key={j}>{item.UserFullName}</p>;
                    })}
                  </>
                )}
              </div>
            );
          })}
        </div>
      </React.Fragment>
    );
  }
}

export default SortingExample;
